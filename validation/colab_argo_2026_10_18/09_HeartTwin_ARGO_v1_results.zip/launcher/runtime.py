"""Shared durable runtime, embedded into each standalone notebook."""
import hashlib, json, os, platform, shutil, subprocess, sys, tempfile, time, traceback
from pathlib import Path
import urllib.request, urllib.error, zipfile

def digest(path, algorithm='sha256'):
 h=hashlib.new(algorithm)
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()

def atomic_json(path, data):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 fd,tmp=tempfile.mkstemp(prefix=path.name+'.',dir=path.parent)
 try:
  with os.fdopen(fd,'w') as f:json.dump(data,f,indent=2,sort_keys=True,allow_nan=False)
  os.replace(tmp,path)
 finally:Path(tmp).unlink(missing_ok=True)

def download(url,path,expected=None,algorithm='sha256',size=None):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 receipt=path.with_name(path.name+'.receipt.json')
 if path.exists():
  actual=digest(path,algorithm)
  if size is not None and path.stat().st_size!=size:raise ValueError('Cached file size mismatch: '+str(path))
  if expected and actual!=expected:raise ValueError('Cached checksum mismatch: '+str(path))
  if not expected:
   if not receipt.exists() or json.loads(receipt.read_text())['sha256']!=digest(path):raise ValueError('Untrusted cached download: '+str(path))
   if json.loads(receipt.read_text())['url']!=url:raise ValueError('Cached source URL mismatch: '+str(path))
  if not receipt.exists():atomic_json(receipt,{'url':url,'size':path.stat().st_size,'sha256':digest(path),'producer_checksum':expected,'producer_algorithm':algorithm if expected else None})
  return path
 part=path.with_name(path.name+'.part');offset=part.stat().st_size if part.exists() else 0
 if offset and expected and (size is None or offset==size) and digest(part,algorithm)==expected:
  os.replace(part,path);path.with_name(path.name+'.part.meta.json').unlink(missing_ok=True)
  return download(url,path,expected,algorithm,size)
 partial_meta=path.with_name(path.name+'.part.meta.json')
 headers={'User-Agent':'Virelion-validation/1.0'}
 if offset:
  headers['Range']=f'bytes={offset}-'
  if partial_meta.exists():
   meta=json.loads(partial_meta.read_text())
   if meta['url']!=url:raise ValueError('Partial source URL mismatch')
   if meta.get('validator'):headers['If-Range']=meta['validator']
 for attempt in range(4):
  try:
   with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=90) as r:
    if offset and r.status==206:
     if not r.headers.get('Content-Range','').startswith(f'bytes {offset}-'):raise ValueError('Invalid partial-response offset')
     mode='ab'
    else:mode='wb'
    atomic_json(partial_meta,{'url':url,'validator':r.headers.get('ETag') or r.headers.get('Last-Modified')})
    with part.open(mode) as f:
     for block in iter(lambda:r.read(1<<20),b''):f.write(block)
   break
  except urllib.error.HTTPError as e:
   # A runtime may stop after the final byte but before the final rename.
   if e.code==416 and e.headers.get('Content-Range')==f'bytes */{offset}':break
   if attempt==3:raise
   time.sleep(min(2**attempt,8))
  except (OSError,urllib.error.URLError):
   if attempt==3:raise
   time.sleep(min(2**attempt,8));offset=part.stat().st_size if part.exists() else 0
   if offset:headers['Range']=f'bytes={offset}-'
 if size is not None and part.stat().st_size!=size:raise ValueError('Downloaded file size mismatch: '+url)
 if expected and digest(part,algorithm)!=expected:raise ValueError('Downloaded checksum mismatch: '+url)
 os.replace(part,path)
 partial_meta.unlink(missing_ok=True)
 atomic_json(receipt,{'url':url,'size':path.stat().st_size,'sha256':digest(path),'producer_checksum':expected,'producer_algorithm':algorithm if expected else None})
 return path

def unzip(path,destination):
 destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(path) as z:
  for info in z.infolist():
   target=(destination/info.filename).resolve()
   if not target.is_relative_to(destination.resolve()):raise ValueError('Unsafe archive member')
   if (info.external_attr>>16)&0o170000==0o120000:raise ValueError('Archive contains symlink')
  z.extractall(destination)

class Run:
 def __init__(self, root, protocol, repo_paths):
  self.root=Path(root);self.protocol=protocol;self.repos={k:Path(v) for k,v in repo_paths.items()}
  self.data=self.root/'data';self.out=self.root/'results';self.state=self.root/'state'
  for p in [self.data,self.out,self.state,self.root/'logs']:p.mkdir(parents=True,exist_ok=True)
  self.started=time.monotonic();self.limit=protocol.get('session_seconds',8100)
  encoded=json.dumps(protocol,sort_keys=True,separators=(',',':')).encode()
  self.identity=hashlib.sha256(encoded).hexdigest()
  identity=self.root/'protocol.json'
  if identity.exists() and json.loads(identity.read_text())!=protocol:raise ValueError('Protocol changed: choose a new RUN_LABEL; do not mix checkpoints')
  atomic_json(identity,protocol)
 def paused(self):return time.monotonic()-self.started>=self.limit
 def task(self,name,fn):
  done=self.state/(name+'.json')
  if done.exists():
   old=json.loads(done.read_text())
   if old['identity']!=self.identity:raise ValueError('Stale checkpoint')
   if all((self.root/p).exists() and digest(self.root/p)==sha for p,sha in old['artifacts'].items()):
    print('RESUME completed:',name,flush=True);return old['result']
   raise ValueError('Completed artifacts changed or missing: '+name)
  before={str(p.relative_to(self.root)):digest(p) for directory in [self.out,self.root/'logs'] for p in directory.rglob('*') if p.is_file()}
  result=fn()
  # Receipts bind completion to every result/log artifact present at this boundary.
  artifacts={str(p.relative_to(self.root)):digest(p) for directory in [self.out,self.root/'logs'] for p in directory.rglob('*') if p.is_file()}
  artifacts={p:h for p,h in artifacts.items() if before.get(p)!=h}
  atomic_json(done,{'identity':self.identity,'artifacts':artifacts,'result':result})
  return result
 def command(self,name,args,cwd=None,env=None):
  cmd=[str(x) for x in args];log=self.root/'logs'/(name+'.txt')
  start=time.monotonic()
  with log.open('w') as f:
   f.write('COMMAND '+json.dumps(cmd)+'\n');f.flush()
   code=subprocess.call(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
  atomic_json(self.out/(name+'-execution.json'),{'returncode':code,'seconds':time.monotonic()-start,'command':cmd})
  if code:raise RuntimeError(f'{name} failed ({code}); inspect {log}')
  return {'returncode':code,'log':str(log.relative_to(self.root))}
 def finish(self,status,error=None):
  inputs={str(p.relative_to(self.root)):json.loads(p.read_text()) for p in self.data.rglob('*.receipt.json')}
  atomic_json(self.root/'RUN_STATUS.json',{'status':status,'scientific_validation':'NOT_ESTABLISHED_BY_EXECUTION','scope':self.protocol['scope'],'protocol_sha256':self.identity,'seconds_this_session':time.monotonic()-self.started,'error':error,'source_pins':self.protocol['repos'],'input_receipts':inputs})

def export(root,destination):
 root=Path(root);destination=Path(destination);inventory={};retained={}
 excluded={'.pt','.pth','.tif','.tiff','.png','.jpg','.jpeg','.npy','.npz'}
 for directory in ['results','logs','state','launcher']:
  for p in (root/directory).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts:
    relative=str(p.relative_to(root))
    if p.suffix.lower() in excluded:retained[relative]={'sha256':digest(p),'bytes':p.stat().st_size}
    else:inventory[relative]=digest(p)
 atomic_json(root/'RETAINED_ON_DRIVE.json',retained)
 for p in root.glob('*'):
  if p.is_file() and p.suffix in ['.json','.txt','.log','.ipynb','.md']:inventory[p.name]=digest(p)
 atomic_json(root/'ARTIFACT_HASHES.json',inventory)
 with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as z:
  for relative in sorted(inventory):z.write(root/relative,relative)
  z.write(root/'ARTIFACT_HASHES.json','ARTIFACT_HASHES.json')
 return str(destination)
